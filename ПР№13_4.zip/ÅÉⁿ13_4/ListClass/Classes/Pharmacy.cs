﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListClass.Classes
{
    class Employees
    {
        string nameWorker;
        string postWorker;
        int yearAccesses;

        //свойства
        public string NameWorker
        {
            get { return nameWorker; }
            set { nameWorker = value; }
        }
        public string PostWorker
        {
            get { return postWorker; }
            set { postWorker = value; }
        }
        public int YearAccesses
        {
            get { return yearAccesses; }
            set { yearAccesses = value; }
        }
        //конструкторы
        public Employees()
        {
            nameWorker = "";
            postWorker = "";
            yearAccesses = 0;
        }
        public Employees(string name, string post, int Acess)
        {
            nameWorker = name;
            postWorker = post;
            yearAccesses = Acess;
        }
    }
}
